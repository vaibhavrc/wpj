package com.cdac.entity;

public class Leave {

}
