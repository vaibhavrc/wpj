package com.cdac.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.entity.CompanyDetails;

public interface CompanyDetailsRepository extends JpaRepository<CompanyDetails, Integer>{

}
