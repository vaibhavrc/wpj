package com.cdac.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.entity.AccountDetails;

public interface AccountDetailsRepository extends JpaRepository<AccountDetails, Integer>{

}
